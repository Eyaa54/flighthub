package com.example.flighthub.models;

public enum Role {

    ADMIN, GESTIONNAIRE, AGENT
}
